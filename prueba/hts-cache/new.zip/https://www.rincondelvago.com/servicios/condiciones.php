
<!DOCTYPE html>
<html lang="es" xmlns="http://www.w3.org/1999/xhtml"  xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
<base target="_top" />
<link href="https://plus.google.com/108524715945743684741" rel="publisher" />
<script type="text/javascript">window.___gcfg = {lang: "es"}; (function() {var po = document.createElement("script"); po.type = "text/javascript"; po.async = true;po.src = "https://apis.google.com/js/plusone.js"; var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(po, s); })();</script>
<meta charset="utf-8" />
<title>Encuentra aquí Apuntes, Tareas, Exámenes para tu escuela | Rincón del Vago</title>
<meta name="description" content="Información confiable - Encuentra aquí ✓ ensayos ✓ resúmenes y ✓ herramientas para aprender de ✓ historia ✓ libros ✓ biografias y más temas ¡Da clic!" />
<meta name="keywords" content="apuntes trabajos tareas resumenes monografias ensayos examenes practicas ejercicios amor universidades universidad eso formacion profesional selectividad test tests tecnicas estudio chuletas educacion trabajo ciencia cultura juegos libros" />
<meta name="author" content="rincondelvago.com" />
<meta name="facebook-domain-verification" content="lx899qfdwzt16boxyzpf7s5bfnlp4z" />
<meta name="viewport" content="minimum-scale=1.0, width=device-width, maximum-scale=0.6667, user-scalable=no" />
<meta property="og:title" content="Encuentra aquí Apuntes, Tareas, Exámenes para tu escuela | Rincón del Vago" />
<meta property="og:image" content="https://rdv-files.nyc3.cdn.digitaloceanspaces.com/rinvago/static-content/var/rdv-og.jpg" />
<link rel="icon" type="image/x-icon" href="https://rdv-files.nyc3.cdn.digitaloceanspaces.com/rinvago/static-content/favicon.ico" />
<link rel="shortcut icon" type="image/x-icon" href="https://rdv-files.nyc3.cdn.digitaloceanspaces.com/rinvago/static-content/favicon.ico" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script><script  type="text/javascript">
<!--
/* Classic Analytics */ 

var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-1199446-1']);
_gaq.push(['_setDomainName', '.rincondelvago.com']);
_gaq.push(['_trackPageview']);
(function() {
var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();


/* Universal Analytics */

(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
ga("create", "UA-104623799-3", "auto", { "cookieDomain":"rincondelvago.com" ,"name":"rdv_all_data"});
ga("rdv_all_data.send", "pageview");

//-->
</script>
<script  type="" src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script  type="" src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" async="true"></script>
<script  type="text/javascript" src="https://securepubads.g.doubleclick.net/tag/js/gpt.js" async="async"></script>
<script  type="text/javascript">


    window.googletag = window.googletag || {cmd: []};
		var div_1_sizes = [
				[320, 100],
				[320, 50],
				[300, 250],
				[300, 600]
		];

		var div_2_sizes = [[970, 90], [728, 90],[970, 250]];

			googletag.cmd.push(function() {
							 googletag.defineSlot('/49859683/RDV_web', div_2_sizes, 'div-gpt-ad-1515779430602-1').addService(googletag.pubads());
							 googletag.pubads().enableSingleRequest();
							 googletag.enableServices();
			 });
			googletag.cmd.push(function() {
					 googletag.defineSlot('/49859683/RDV_web', div_2_sizes, 'div-gpt-ad-1515779430602-2').addService(googletag.pubads());
					 googletag.pubads().enableSingleRequest();
					 googletag.enableServices();
			 });
			 googletag.cmd.push(function() {
 							 googletag.defineSlot('/49859683/RDV_web', div_2_sizes, 'div-gpt-ad-1515779430602--3').addService(googletag.pubads());
 							 googletag.pubads().enableSingleRequest();
 							 googletag.enableServices();
 			 });
 			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_2_sizes, 'div-gpt-ad-1515779430602--4').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });
			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_2_sizes, 'div-gpt-ad-1515779430602--5').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });
			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_1_sizes, 'div-gpt-ad-1515779430602--6').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });
			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_1_sizes, 'div-gpt-ad-1515779430602--7').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });
			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_1_sizes, 'div-gpt-ad-1515779430602--8').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });
			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_1_sizes, 'div-gpt-ad-1515779430602--9').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });
			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_1_sizes, 'div-gpt-ad-1515779430602--10').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });
			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_1_sizes, 'div-gpt-ad-1515779430602--11').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });
			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_1_sizes, 'div-gpt-ad-1515779430602--12').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });
			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_1_sizes, 'div-gpt-ad-1515779430602--13').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });
			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_1_sizes, 'div-gpt-ad-1515779430602--14').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });
			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_1_sizes, 'div-gpt-ad-1515779430602--15').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });
			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_1_sizes, 'div-gpt-ad-1515779430602--16').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });
			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_1_sizes, 'div-gpt-ad-1515779430602--17').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });
			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_1_sizes, 'div-gpt-ad-1515779430602--18').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });
			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_1_sizes, 'div-gpt-ad-1515779430602--19').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });
			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_1_sizes, 'div-gpt-ad-1515779430602--20').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });
			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_1_sizes, 'div-gpt-ad-1515779430602--21').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });
			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_1_sizes, 'div-gpt-ad-1515779430602--22').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });
			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_1_sizes, 'div-gpt-ad-1515779430602--23').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });
			 googletag.cmd.push(function() {
 					 googletag.defineSlot('/49859683/RDV_web', div_1_sizes, 'div-gpt-ad-1515779430602--24').addService(googletag.pubads());
 					 googletag.pubads().enableSingleRequest();
 					 googletag.enableServices();
 			 });

        
</script>
<script  type="text/javascript">
<!--
var c_AK = "5a";

var _rdv_integration = false;
$(function(){
_rdv_integration = (($("body").attr("style") == undefined || $("body").attr("style") == "") ? false : true);
$(".clickable").on("click","a",function(){ e.stopPropagation(); });
$(".clickable").on("click",function(e){
	var link = $(this).find("a");
	if (e.ctrlKey || e.shiftKey || e.metaKey) { var target = link.attr("target"); link.attr("target","_blank").get(0).click(); link.attr("target",target); } else { link.get(0).click(); }
});


$("#headerBtnMenu").click(function(e)
{
    $("#navMenu").toggleClass("hide-phone");
    $("#navList li").toggleClass("open");
    e.stopPropagation();
});
$("#headerSearchForm").on("submit", function(event)
{
	event.preventDefault();
	var query = $.trim($("#headerSearchQ").val()); if (query.length == 0) {return false;}
	location.href = "https://buscador.rincondelvago.com/" + query.replace(/[^ a-záâàäéêèëíîìïóôòöúûùüçñA-ZÁÂÀÄÉÊÈËÍÎÌÏÓÔÒÖÚÛÙÜÇÑ0-9'"]/g,"").replace(/ /g,"+");
});

// breadCrumbs
if (_rdv_integration == true){ $("#breadCrumb").addClass("bg");}
});

			var googletag = googletag || {};
			googletag.cmd = googletag.cmd || [];

/*
			var top_large_mapping = googletag.sizeMapping()
								.addSize([1024,300], [[970, 250], [970, 90], [728, 90]])
								.addSize([728,300], [728, 90])
								.addSize([0,0], [[320, 100], [320, 50]])
								.build();

			var middle_large_mapping = googletag.sizeMapping()
								.addSize([1024,300], [728, 90])
								.addSize([728,300], [728, 90])
								.addSize([0,0], [[320, 100], [320, 50]])
								.build();

            var box_mapping_top = googletag.sizeMapping()
                                .addSize([728,300], [[300, 250], [300, 600]])
                                .addSize([0,0], [[320, 100], [320, 50]])
                                .build();

			var box_mapping = googletag.sizeMapping()
								.addSize([728,300], [[300, 250]])
								.addSize([0,0], [[320, 100], [320, 50]])
								.build();*/
		
			googletag.cmd.push(function() {
				googletag.defineSlot('/49859683/RDV_web/Ros_Top', [[970, 250], [970, 90], [728, 90], [320, 100], [320, 50]], 'div-gpt-ad-1503331996962-0')
				.setTargeting('pos',['LB_1_HP_D'])
    			.defineSizeMapping(googletag.sizeMapping()
								.addSize([1024,300], [[970, 250], [970, 90], [728, 90]])
								.addSize([728,300], [728, 90])
								.addSize([0,0], [[320, 100], [320, 50]])
								.build())
    			.addService(googletag.pubads());
    		googletag.pubads().enableSingleRequest();
    		googletag.pubads().collapseEmptyDivs();
   			googletag.enableServices();
 			 });
 		

 				googletag.cmd.push(function() {
 					googletag.defineSlot('/49859683/RDV_web/Ros', [[728, 90], [320, 100], [320, 50]] , 'div-gpt-ad-1503333285598-0')
 					.defineSizeMapping(googletag.sizeMapping()
								.addSize([1024,300], [728, 90])
								.addSize([728,300], [728, 90])
								.addSize([0,0], [[320, 100], [320, 50]])
								.build())
 					.setTargeting('pos',['LB_4_HP_D'])
 					.addService(googletag.pubads());
 					googletag.pubads().enableSingleRequest();
 					googletag.pubads().collapseEmptyDivs();
 					googletag.enableServices();
  					});
 				
 				 googletag.cmd.push(function() {
    				googletag.defineSlot('/49859683/RDV_web/Ros_Top', [[300, 250], [300, 600], [320, 50], [320, 100]], 'div-gpt-ad-1503332424360-0')
    				.defineSizeMapping(googletag.sizeMapping()
                                .addSize([728,300], [[300, 250], [300, 600]])
                                .addSize([0,0], [[320, 100], [320, 50]])
                                .build())
 					.setTargeting('pos',['MREC_1_HP_D'])
    				.addService(googletag.pubads());
    				googletag.pubads().enableSingleRequest();
    				googletag.pubads().collapseEmptyDivs();
    				googletag.enableServices();
 				 });
 			

 				googletag.cmd.push(function() {
    				googletag.defineSlot('/49859683/RDV_web/Ros', [[300, 250], [320, 50], [320, 100]], 'div-gpt-ad-1503332688548-0')
    				.defineSizeMapping(googletag.sizeMapping()
								.addSize([728,300], [[300, 250]])
								.addSize([0,0], [[320, 100], [320, 50]])
								.build())
 					.setTargeting('pos',['MREC_2_HP_D'])
    				.addService(googletag.pubads());
    			googletag.pubads().enableSingleRequest();
    			googletag.pubads().collapseEmptyDivs();
    			googletag.enableServices();
  				});

 			
//
// Begin comScore Tag

var _comscore = _comscore || [];
_comscore.push({ c1: "2", c2: "5641052" });
(function() {
var s = document.createElement("script"), el = document.getElementsByTagName("script")[0]; s.async = true;
s.src = (document.location.protocol == "https:" ? "https://sb" : "https://b") + ".scorecardresearch.com/beacon.js";
el.parentNode.insertBefore(s, el);
})();

// End comScore Tag
//

//-->
</script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://rdv-files.nyc3.cdn.digitaloceanspaces.com/rinvago/static-content/css/main.20171127.css" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
</head>
<body>

		<style>
			header{background-color:#2f2f2f}header .row{margin:0}header #headerdiv{width:940px;padding:5px 0;margin:0 auto}header .btn-toolbar{padding:0;margin:0}header .btn-toolbar.right{padding:0}header #logoName{padding:0;margin:0}header #headerSearch{white-space:nowrap;margin:0}header #headerSearch #headerSearchSubmit{padding:7px;border-radius:0;border:0;background:0 0;color:#666;text-shadow:none;box-shadow:none}header #headerSearch #headerSearchSubmit:active,header #headerSearch #headerSearchSubmit:hover{box-shadow:none!important}header #headerSearch #headerSearchQ{background:0 0;color:#ccc;font-style:oblique;border:none;border-bottom:1px solid #666}@media (max-width:940px) and (min-width:767px){header #headerSearch #headerSearchQ{width:200px}}@media (max-width:940px){header #headerdiv{width:100%}}
		</style>



			
				<header>
					<div class="row">
						<div id="headerdiv">
							<div class="left"><a href="https://www.rincondelvago.com" title="Inicio"><img src="https://rdv-files.nyc3.cdn.digitaloceanspaces.com/rinvago/static-content/pixel.gif" id="logoName" alt="" title="" width="300" height="47" /></a>			</div>
							<div class="right btn-toolbar">
								<div id="headerSearch" class="hide-phone left">
									<form id="headerSearchForm" method="post" action="https://buscador.rincondelvago.com">
										<input id="headerSearchQ" class="gbg" type="text" name="q" placeholder="Buscar" />
										<button name="searchbutton" type="submit"  id="headerSearchSubmit">
											<i class="fa fa-search fa-lg" aria-hidden="true"></i>
										</button>
									</form>
								</div>
							</div>
						</div>
					</div>
				</header>
				
<nav><div id="nav"><ul id="navList"><li><button id="headerBtnMenu" type="button" aria-label="headerBtnMenu"  name="headerBtnMenu" class="btn btn-black visible-phone"><i class="fa fa-bars" aria-hidden="true"></i></button><ul id="navMenu" class="hide-phone"><li class="divider visible-phone"></li><li class="nav cur"><a href="https://www.rincondelvago.com" class="nav first cur">Inicio<i class="rdv-icon-chevron-right visible-phone"></i></a></li><li class="nav visible-phone"><form method="get" action="https://buscador.rincondelvago.com"><input type="search" placeholder="Buscar" name="q" class="search"/><button type="submit" name="sub" class="fa fa-arrow-circle-right submit"/></form></li><li class="divider"></li><li class="nav"><a href="https://apuntes.rincondelvago.com" class="nav">Documentos<i class="rdv-icon-chevron-right visible-phone"></i></a></li><li class="divider"></li><li class="nav"><a href="https://tests.rincondelvago.com" class="nav">Tests<i class="rdv-icon-chevron-right visible-phone"></i></a></li><li class="divider"></li><li class="nav"><a href="https://amor.rincondelvago.com" class="nav">Amor<i class="rdv-icon-chevron-right visible-phone"></i></a></li><li class="divider"></li><li class="nav"><a href="https://www.rincondelvago.com/revista/magazine/" class="nav">Magazine<i class="rdv-icon-chevron-right visible-phone"></i></a></li><li class="divider"></li><li class="nav"><a href="https://www.rincondelvago.com/revista/creaciones/" class="nav">Creaciones<i class="rdv-icon-chevron-right visible-phone"></i></a></li><li class="divider"></li><li class="nav"><a href="https://blog.rincondelvago.com" class="nav">Blog<i class="rdv-icon-chevron-right visible-phone"></i></a></li><li class="hide-phone divider"></li></ul></li><li class="divider visible-phone"></li><li class="right"><ul id="navSoc"><li class="soc"><ul class="soc"><li><a href="http://facebook.com/elrincondelvago" class="soc" name="facebook" target="_blank"><i class="fa fa-facebook-square rdv-icon-soc-facebook"></i></a></li><li><a href="http://twitter.com/elrincondelvago" class="soc" name="twitter" target="_blank"><i class="fa fa-twitter-square rdv-icon-soc-twitter"></i></a></li><li><a href="https://plus.google.com/108524715945743684741" class="soc" name="gplus" target="_blank"><i class=" fa fa-google-plus-square rdv-icon-soc-gplus"></i></a></li></ul></li></ul></li></ul><div class="clear"></div></div></nav>

			<style>
			#docData h1{color:#333;font-size:25px;line-height:30px;font-style:oblique}nav{width:100%;background-color:#6183a3;margin-bottom:10px}nav #nav{width:940px;margin:auto}@media(max-width:940px){nav #nav{width:100%}}nav [class*=" icon-"],nav [class^=icon-]{display:inline-block;width:14px;height:14px;margin-top:1px;line-height:14px;vertical-align:text-top;background-image:url(../img/glyphicons-halflings.png);background-position:14px 14px;background-repeat:no-repeat}nav [class*=" rdv-icon-"],nav [class^=rdv-icon-]{display:inline-block;margin-top:1px;line-height:14px;vertical-align:text-top;background-image:url(https://img.rincondelvago.com/img/sprites.png);background-position:14px 14px;background-repeat:no-repeat}#nav .rdv-icon-soc-facebook,#nav .rdv-icon-soc-gplus,#nav .rdv-icon-soc-twitter,nav #nav .rdv-icon-list{font-size:24px;color:#fff}nav #nav #headerBtnMenu.btn:active{color:#fff}nav #nav li.cur{background:#ff7212}nav #nav li.cur:hover{background:#ff7212;color:#FFF}nav #nav li.cur:hover a.nav{color:#fff}@media (max-width:767px){div.ad728x90{width:320px}nav #nav a.soc{display:block;padding:10px 8px}}
			</style>
		
<!-- device:computer- home--><!--INFOLINKS_OFF--><div id="div-gpt-inters-1483518875636-0">
  <script type='text/javascript'>
    googletag.cmd.push(function() {
      googletag.defineOutOfPageSlot('/49859683/rincon-intersticial-movil', 'div-gpt-inters-1483518875636-0').addService(googletag.pubads());
      googletag.pubads().enableSyncRendering();
      googletag.enableServices();

      googletag.display('div-gpt-inters-1483518875636-0');
  });
  </script>
</div>
<div id="adTop_especial">
				<div class="ctr900_especial">
					<div id='rdv_ad_900x90' class='ad '>
						<!-- /49859683/RDV_web/Ros_Top -->
						<div id='div-gpt-ad-1503331996962-0'>
						<script>
							googletag.cmd.push(function() { googletag.display('div-gpt-ad-1503331996962-0'); });
						</script>
						</div>
					</div></div>
				</div>
<div id="global">
<div id="main">
<!--INFOLINKS_ON-->
<div class="box">
	<h1>CONDICIONES DE USO DEL PORTAL RINCONDELVAGO.COM</h1>
	
	<h2>PRIMERO: OBJETO DEL SERVICIO-.</h2>

	Orange Horizons Latina, S.A. de C.V. , a través del portal de Internet, "Rincondelvago.com", ofrece principalmente un servicio gratuito llamado "APUNTES", mediante el cual, los usuarios de la web y el público en general tendrán acceso a una colección de ficheros que contienen trabajos, monografías, recensiones, informes, apuntes, exámenes, tests, prácticas, problemas, ejercicios, textos de apoyo y en general cualquier tipo de documentación académica, enviada a Rincondelvago.com por sus respectivos autores. Dicho servicio de "APUNTES" se ve complementado por una serie de utilidades, secciones y contenidos relacionados con la finalidad principal, cuyo contenido, ubicación y/o finalidad pueden ser modificadas discrecionalmente por Orange Horizons Latina, S.A. de C.V.

	<br /><br />
	<h2>SEGUNDO: CONDICIONES-.</h2>

	El uso del mencionado portal se sujetará a las siguientes Condiciones, las cuales podrán ser actualizadas periódicamente y sin previo aviso. Igualmente la firma responsable del portal "Rincondelvago.com" se reserva el derecho de modificar, en cualquier momento y sin previo aviso, el nombre u otras características de la sección donde se ofrece el citado servicio de documentación académica. El uso del presente servicio presume la perfecta comprensión y la expresa aceptación de las mencionadas condiciones por parte del usuario.
	<br /><br />
	Dichos términos son igualmente aplicables a cualesquiera otras secciones temáticas y/o apartados de la web "Rincondelvago.com"

	<br /><br />
	<h2>TERCERO: MODIFICACIÓN / SUPRESIÓN DEL SERVICIO-.</h2>
	Orange Horizons Latina, S.A. de C.V.  se reserva el derecho de mejorar, modificar o suprimir, unilateralmente y sin previo aviso, los servicios y/o contenidos de este portal atendiendo a los más diversos criterios.

	<br /><br />
	<h2>CUARTO: TITULARIDAD DE PROPIEDAD INTELECTUAL E INDUSTRIAL.</h2>
	El usuario del servicio reconoce expresamente la exclusiva titularidad de Orange Horizons Latina, S.A. de C.V.  sobre cualesquiera derechos de propiedad intelectual e industrial concernientes a las páginas que dan soporte a todos los servicios y contenidos del portal "Rincondelvago.com" , en particular en lo referente a la apariencia o "look & feel", imágenes, combinación de colores, logotipos gráficos y/o dibujos de las mismas. Dicha obligación de reconocimiento subsistirá aun en el caso de haberse suprimido el presente servicio.
	<br /><br />
	Orange Horizons Latina, S.A. de C.V.  reconoce expresamente que, la autoría de los documentos académicos publicados en la sección "APUNTES" corresponde a las personas remitentes de los ficheros que los contienen, a quienes Rincondelvago.com presume autores, en tanto en cuanto cualesquiera otras personas no justifiquen, de forma fehaciente, poseer derechos o intereses legítimos sobre el citado documento. No obstante lo anterior, los autores-remitentes de ficheros que contienen documentación académica en general, reconocen expresamente y sin que medie contraprestación económica alguna, que Rincondelvago.com obstenta en exclusiva los derechos de reproducción, comunicación pública, distribución y transformación sobre la citada documentación académica. El mero hecho de enviar o remitir ficheros o archivos con documentación académica a la sede o a los servidores del portal Rincondelvago.com supone la perfecta comprensión y la expresa aceptación de las mencionadas condiciones por parte del usuario.
	<br /><br />
	El usuario del servicio de "APUNTES" que mediante cualesquiera procedimientos existentes en la actualidad o en el futuro, visualice o descargue archivos (download) de la sección en que se presta este servicio, reconoce expresamente la titularidad exclusiva de Rincondelvago.com sobre los derechos de reproducción, comunicación pública, distribución y transformación relativos a las obras contenidas en dichos archivos o ficheros.

	<br /><br />
	<h2>QUINTO: AUTOPROMOCIONES Y PERMISSION E-MAIL MARKETING-.</h2>
	Orange Horizons Latina, S.A. de C.V.  podrá enviar a sus usuarios registrados, cumpliendo todas las especificaciones legales y mediante correo electrónico, autopromociones y boletines informativos, sobre sus contenidos y servicios, que podrían contener publicidad del propio portal "Rincondelvago.com" o de otras webs y/o empresas.
	<br /><br />
	Asímismo el usuario del portal "Rincondelvago.com" manifiesta su conformidad para que Orange Horizons Latina, S.A. de C.V.  facilite el servicio de "permission e-mail marketing", consistente en suministrar mediante e-mail, y previa la expresa autorización del usuario, información y publicidad sobre productos y servicios derivados de las áreas de interés que el usuario ha señalado al darse de alta en cualquiera de las secciones de este canal para cuyo acceso se requiera el registro previo.
	<br /><br />
	Para la efectividad del mencionado servicio de "permission e-mail marketing", el usuario de "Rincondelvago.com" se compromete a lo siguiente: 
	<br /><br />
	(1) facilitar determinada información actualizada, completa y veraz sobre sí mismo, de acuerdo con lo solicitado por el Servicio y
	<br /><br />
	(2) mantener y actualizar dicha información para conservarla completa y veraz.
	<br /><br />
	El usuario del portal "Rincondelvago.com", a fin de poder ser usuario del servicio de "permission e-mail marketing", otorgará en su caso a Orange Horizons Latina, S.A. de C.V. , mediante la cumplimentación del formulario de registro/alta en cualquiera de las secciones del portal, el derecho a dar a conocer a terceras empresas determinada Información de Registro acerca de sí mismo y de su condición de usuario del portal. No obstante se excluye expresamente de la información a suministrar a estas terceras empresas el nombre del usuario, el domicilio, el E-mail, el número de cuenta y el número telefónico, en su caso, a fin de cumplimentar el procedimiento de disociación que supondrá que la información que se obtenga no pueda asociarse a persona identificada o identificable.
	<br /><br />
	Para el envío de toda clase de autopromociones e informaciones publicitarias, Orange Horizons Latina, S.A. de C.V.  requerirá la aceptación expresa del usuario a través de su "zona de registro de usuarios"

	<br /><br />
	<h2>SEXTO: RESPONSABILIDADES Y ACTOS PROHIBIDOS-.</h2>
	El usuario del servicio se compromete a no realizar descargas masivas de ficheros, mediante cualesquiera procedimientos y/o programas, y a destinar el documento o los documentos descargado/s de la sección "APUNTES" al uso meramente privado, no pudiendo en ningún caso el usuario publicar, distribuir o comercializar de ninguna forma cualquiera de los contenidos del presente servicio y, en general de "Rincondelvago.com".
	<br /><br />
	Quedan absolutamente prohibidos, sea cual fuere el medio utilizado para ello, el uso, la comunicación, la distribución y la publicación de enlaces directos o links a los ficheros publicados en la sección "APUNTES" o en cualesquiera otros apartados de Rincondelvago.com. La infracción de la presente condición facultará a Orange Horizons Latina, S.A. de C.V.  para perseguir a los responsables de dichas acciones, con cuantos medios legales se encuentren a su alcance, tanto para que cesen en dichas acciones, como con el fin de resarcirse del posible daño económico y/o moral producido a Orange Horizons Latina, S.A. de C.V.
	<br /><br />
	Orange Horizons Latina, S.A. de C.V.  no garantiza ni se hace cargo de la calidad, exactitud, fiabilidad, corrección o moralidad de los datos, textos, gráficos o imágenes, en su caso, introducidos en los documentos académicos ni de las opiniones personales vertidas en los mismos por sus respectivos autores-remitentes. En general, el autor-remitente de un documento se obliga a no utilizar las facilidades y capacidades ofrecidas por este servicio para realizar o sugerir actividades prohibidas por la ley o que atenten contra la moral y las buenas costumbres. Asimismo los autores-remitentes se hacen responsables de extender el cumplimiento de estas cláusulas a toda aquella persona autorizada por él a usar el servicio. A dicho efecto, el usuario de este servicio acepta expresamente dejar exenta a Orange Horizons Latina, S.A. de C.V.  de cualquier responsabilidad relacionada con el uso de este servicio.
	<br /><br />
	El usuario de este servicio asume bajo su exclusiva responsabilidad las consecuencias, daños o acciones que pudieran derivarse del uso de las posibilidades que el portal Rincondelvago.com pone a su disposición para publicar ficheros de documentación académica, cuando los textos, combinación de colores, dibujos, imágenes o logotipos introducidos por el usuario afecten a los derechos de cualquier visitante o usuario de esta web, o de terceros, incluyendo los derechos de copyright, marcas, patentes, información confidencial y cualquier otro derecho de propiedad intelectual o industrial, sin olvidar todos aquellos que vulneren o transgredan el honor, la intimidad personal o familiar o la imagen de terceros, o que sean ilícitos o atenten a la moralidad, dejando el usuario en todo caso indemne a Orange Horizons Latina, S.A. de C.V.  frente a cualquier reclamación, judicial o extrajudicial.
	<br /><br />
	El usuario se obliga a no utilizar las facilidades y capacidades ofrecidas por este servicio para realizar o sugerir actividades prohibidas por la ley. Asimismo el usuario del servicio se hace responsable de extender el cumplimiento de estas cláusulas a toda aquella persona autorizada por él a usar el servicio.
	<br /><br />
	El autor-remitente de documentación académica para su publicación en la sección "APUNTES" de Rincondelvago.com se compromete a facilitar datos ciertos y veraces en el formulario de registro, o en el correo electrónico en el que adjunte el documento a publicar.
	<br /><br />
	Orange Horizons Latina, S.A. de C.V. , titular del portal Rincondelvago.com, se reserva el derecho de no publicar un determinado documento, cancelando los datos de su autor-remitente, atendiendo a las más diversas circunstancias relacionadas con la calidad, características y procedencia de dichos documentos.
	<br /><br />
	Las disposiciones establecidas en el presente apartado "SEXTO" serán igualmente aplicables a cualesquiera otros servicios y contenidos ofrecidos a través del portal "Rincondelvago.com".

	<br /><br />
	<h2>SÉPTIMO: FUNCIONAMIENTO DEL SERVICIO-.</h2>
	Orange Horizons Latina, S.A. de C.V.  no será responsable de ningún daño que se genere al usuario en caso de imposibilidad de prestar los servicios y/o contenidos objeto de las presentes Condiciones de Uso, debida a supuestos de caso fortuito, fuerza mayor u otras causas no imputables a Orange Horizons Latina, S.A. de C.V.
	<br /><br />
	En ningún caso Orange Horizons Latina, S.A. de C.V.  será responsable del inadecuado funcionamiento del presente servicio si ello obedece a labores de mantenimiento y similares, a incidencias que afecten a servidores u operadores internacionales, a una defectuosa configuración de los equipos del usuario o a su insuficiente capacidad para soportar los sistemas informáticos indispensables para poder hacer uso del servicio.
	<br /><br />
	Por otra parte, Orange Horizons Latina, S.A. de C.V.  expresa su diligente intención de procurar que los ficheros que contienen documentación académica enviada por los usuarios de la web, sean publicados lo antes posible. No obstante "Rincondelvago.com" no garantiza un plazo de tiempo en el que dicha publicación vaya a producirse o, incluso, si dicha publicación vaya a tener lugar, eximiendo el usuario a Orange Horizons Latina, S.A. de C.V.  de cualquier responsabilidad por dicha causa.

	<br /><br />
	<h2>OCTAVO: PROTECCIÓN DE DATOS-.</h2>
	Respecto a la Protección de Datos de Carácter Personal, Orange Horizons Latina, S.A. de C.V.  informa a los autores-remitentes de documentación académica de la existencia de un fichero automatizado de datos de carácter personal creado con la finalidad de realizar el mantenimiento y gestión de la relación con el usuario.
	<br /><br />
	Orange Horizons Latina, S.A. de C.V.  advierte al usuario que, la propia finalidad de este servicio exige que determinados datos introducidos en el formulario de registro sean de público conocimiento para otros usuarios del mismo (como por ejemplo la autoría, real o mediante "nick" o "alias" -existiendo también la posibilidad de permanecer en anonimato- o el país de procedencia), asumiendo el usuario bajo su exclusiva responsabilidad las consecuencias, daños o acciones que pudieran derivarse del acceso a dichos contenidos así como de su reproducción o difusión. No obstante, Orange Horizons Latina, S.A. de C.V.  garantiza la privacidad y confidencialidad de las direcciones de correo electrónico de los autores-remitentes.
	<br /><br />
	Orange Horizons Latina, S.A. de C.V.  informa a los usuarios de su web que las páginas web del portal Rincondelvago.com están alojadas en servidores domiciliados en Estados Unidos, y que los derechos de acceso, rectificación, oposición y cancelación de los datos personales recogidos a través del portal Rincondelvago.com podrán ser ejercitados por el Usuario, y en su caso quien lo represente, ante Orange Horizons Latina, S.A. de C.V.  mediante solicitud escrita y firmada dirigida a la siguiente dirección: Orange Horizons Latina, S.A. de C.V.  - Departamento de Atención al Cliente, Jaime Balmes No 8 Mezzanine 2 Col. Los Morales Polanco, CP 11510, Mexico city, Mexico. Dicha solicitud deberá contener los siguientes datos: nombre y apellidos del CLIENTE de conexión, domicilio a efectos de notificaciones, fotocopia del Documento Nacional de Identidad o Pasaporte, y petición en que se concreta la solicitud. En el caso de representación, deberá probarse la misma mediante documento fehaciente.
	<br /><br />
	Orange Horizons Latina, S.A. de C.V.  se compromete al cumplimiento de su obligación de secreto de los datos de carácter personal y de su deber de guardarlos, y adoptará las medidas necesarias para evitar su alteración, pérdida, tratamiento o acceso no autorizado, de acuerdo con lo establecido por la legislación de México, Distrito Federal.
</div>
<div class="clear"></div>
</div><div class="container">
					<div id='div-gpt-ad-1515779430602-2'>
							<script type='text/javascript'>
									googletag.cmd.push(function() { googletag.display('div-gpt-ad-1515779430602-2'); });
							</script>
					</div>
						</div></main>		<style>
		 .btn-facebook{
		 	background-color: #29487d;
			color: #fff;
		 }
		 .btn-google{
		 	background-color: #c1272e;
			color: #fff;
		 }
		 .form-group-ingreso{
			background-color: #f3f3f3;
			padding: 10px;
			margin: 10px;
			font-size: 15px;
			font-weight: bold;
			border-radius: 10px;

		 }
		 .a:focus,.a:active {
			   outline: none !important;
			   box-shadow: none;
			}
		 .btn:focus,.btn:active {
			   outline: none !important;
			   box-shadow: none;
			}
			.btn.active.focus, .btn.active:focus, .btn.focus, .btn:active.focus, .btn:active:focus, .btn:focus {
			    outline: 0;
			}
			*:focus {
			    outline: none;
			}
		</style>

		<script>
	  window.fbAsyncInit = function() {
	    FB.init({
	      appId      : '142168949812203',
	      cookie     : true,
	      xfbml      : true,
	      version    : 'v2.12'
	    });

	    FB.AppEvents.logPageView();
			FB.getLoginStatus(function(response) {
				checkStatusChange(response);

			});
	  };

	  (function(d, s, id){
	     var js, fjs = d.getElementsByTagName(s)[0];
	     if (d.getElementById(id)) {return;}
	     js = d.createElement(s); js.id = id;
	     js.src = "https://connect.facebook.net/en_US/sdk.js";
	     fjs.parentNode.insertBefore(js, fjs);
	   }(document, 'script', 'facebook-jssdk'));

		 function checkStatusChange(response){
			 if (response.status === "connected"){
				 			 }
		 }


	 function iniciarSesionFacebook(){
		 FB.login(function(response){
			 checkStatusChange(response);
		 },{scope:'public_profile,email,user_birthday',auth_type: 'rerequest'});
	 }

	 function fbLogout() {
        FB.logout(function (response) {
            window.location.reload();
        });
    }

</script>





		<div class="modal fade" id="identificarseModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
					  <div class="modal-dialog" role="document">
					    <div class="modal-content">
					      <div class="modal-header">
					        <h5 class="modal-title">Ingresar </h5>
					        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
					          <span aria-hidden="true">&times;</span>
					        </button>
					      </div>
					      <div class="modal-body">

									<ul class="nav nav-tabs" id="registroTab" role="tablist">
									  <li class="nav-item">
									    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#iniciarSesion" role="tab" aria-controls="iniciarSesion" aria-selected="true">Iniciar sesión</a>
									  </li>
									  <li class="nav-item">
									    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#registro" role="tab" aria-controls="registro" aria-selected="false">Registro</a>
									  </li>
									</ul>
									<div class="tab-content" id="registroTabContent">
										<br/>
									  <div class="tab-pane fade show active" id="iniciarSesion" role="tabpanel" aria-labelledby="registro">
											<!--
											<button onclick="iniciarSesionFacebook()" type="button" class="btn btn-facebook btn-lg btn-block"><i class="fa fa-facebook" aria-hidden="true"></i>acebook</button>
											<button type="button" class="btn btn-google btn-lg btn-block"><i class="fa fa-google-plus" aria-hidden="true"></i></button>
											-->
											<div class="form-group-ingreso">
												<div class="form-group">
											    <label for="exampleInputEmail1">Correo electrónico</label>
											    <input type="email" class="form-control" name="correo" id="correoInput" aria-describedby="emailHelp" placeholder="Enter email">
											  </div>
											  <div class="form-group">
											    <label for="exampleInputPassword1">Contraseña</label>
											    <input type="password" class="form-control" name="contrasena" id="contrasenaInput" placeholder="Password">
											  </div>
												<button type="button" onclick="identificarseAction()" class="btn btn-primary btn-lg btn-block">Identificarse</button>
											</div>


									  </div>
									  <div class="tab-pane fade" id="registro" role="tabpanel" aria-labelledby="registro-tab">
												<br/>
												<div>

												</div>
												<div class="form-group-ingreso">
													<div class="form-group">
												    <label for="exampleInputEmail1Reg">Correo electrónico</label>
												    <input type="email" class="form-control" name="correoReg" id="correoInputReg" aria-describedby="emailHelp" placeholder="Enter email">
												  </div>
												  <div class="form-group">
												    <label for="exampleInputPassword1Reg">Contraseña</label>
												    <input type="password" class="form-control" name="contrasenaReg" id="contrasenaInputReg" placeholder="Password">
												  </div>
													<div class="form-group">
												    <label for="exampleInputPassword1Reg">Confirmar contraseña</label>
												    <input type="password" class="form-control" name="ccontrasenaReg" id="ccontrasenaInputReg" placeholder="Confirmar password">
												  </div>
													<div class="form-group">
												    <label for="exampleInputEmail1Reg">Nombre (s)</label>
												    <input type="text" class="form-control" name="nombreReg" id="nombresInputReg" aria-describedby="emailHelp" placeholder="Ingresa tu(s) nombres">
												  </div>
													<div class="form-group">
												    <label for="exampleInputEmail1Reg">Apellidos</label>
												    <input type="text" class="form-control" name="apellidos" id="apellidosInputReg" aria-describedby="emailHelp" placeholder="Ingresa tus apellidos">
												  </div>
													<div class="form-group">
												    <label for="exampleInputEmail1Reg">Fecha de nacimiento</label>
												    <input type="date" class="form-control" name="fechaReg" id="fechaReg" aria-describedby="emailHelp" placeholder="dd/MM/yyyy">
												  </div>
													<div class="form-group">
												    <label for="exampleInputEmail1Reg">Telefono</label>
												    <input type="phone" class="form-control" name="telefonoReg" id="telefonoReg" aria-describedby="emailHelp" placeholder="55 5555 5555">
												  </div>
													<div class="form-group">
												    <label for="exampleInputEmail1Reg">Sexo</label>
														<select class="form-control" id="sexoReg" name="sexoReg">
															<option value="1">Masculino</option>
															<option value="2">Femenino</option>
														</select>
												  </div>
													<button type="button" onclick="registrarseAction()" class="btn btn-primary btn-lg btn-block">Registrarse</button>
												</div>
									  </div>
									</div>
					      </div>
					    </div>
					  </div>
					</div>
					<form action="https://www.rincondelvago.com/acciones/upload.php" method="post" enctype="multipart/form-data">
					<div class="modal fade" id="subirArchivoModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
								  <div class="modal-dialog modal-lg" role="document">
								    <div class="modal-content">
								      <div class="modal-header">
								        <h5 class="modal-title"> Subir Tarea</h5>
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								          <span aria-hidden="true">&times;</span>
								        </button>
								      </div>
								      <div class="modal-body">

												<div class="form-group">
											    <label for="">Titulo</label>
											    <input required="" type="text" class="form-control" name="titulo" id="tituloPub">
											  </div>
												<div class="form-group">
											    <label for="">Seleccionar archivo (doc,pdf)</label>
											    <input type="file" name="file">
											  </div>
								      </div>
								      <div class="modal-footer">
								        <button class="btn btn-primary">Guardar</button>
								        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
								      </div>
								    </div>
								  </div>
								</div>
							</form>
											<script>


				function registrarseAction(){

						if (isEmpty("correoInputReg")
								 || isEmpty("contrasenaInputReg")  || isEmpty("ccontrasenaInputReg")
							 	|| isEmpty("nombresInputReg")  || isEmpty("apellidosInputReg")
							|| isEmpty("fechaReg")  || isEmpty("telefonoReg")){
								alert("Debes de ingresar todos los campos");
						}else if (getValueByID("contrasenaInputReg") != getValueByID("ccontrasenaInputReg")){
							alert("Las contraseñas no coinciden.");
						}else{
							var correo = getValueByID("correoInputReg");
							var contrasena = getValueByID("contrasenaInputReg");
							var nombres = getValueByID("nombresInputReg");
							var apellidos = getValueByID("apellidosInputReg");
							var fechas = getValueByID("fechaReg");
							var telefono = getValueByID("telefonoReg");
							var sexo = getValueByID("sexoReg");
							var urlStr = "https://www.rincondelvago.com/acciones/registrarse.php?correo="+correo
								+"&contrasena="+contrasena+"&nombres="+nombres+"&apellidos="+apellidos
								+"&fechas="+fechas +"&telefono="+telefono +"&sexo="+(sexo==1?"true":"false");
							location.href= urlStr;


						}


				}

				function identificarseAction(){
					if (isEmpty("correoInput") || isEmpty("contrasenaInput")){
						alert("Debes de ingresar los campos");
					}else{
						var correoVar = getValueByID("correoInput");
						var contrasenaInput = getValueByID("contrasenaInput");
						location.href="https://www.rincondelvago.com/acciones/identificarse.php?usuarioNuevo=1&correo="+correoVar+"&contrasena="+contrasenaInput;
						//alert("En mantemimiento de las sesiones favor de intentar mas tarde.");
					}

				}

				function getValueByID(idInput){
					return document.getElementById(idInput).value;
				}

				function isEmpty(idInput){
					if (document.getElementById(idInput).value == null ||
							document.getElementById(idInput).value == ""){
						return true;
					}
					return false;
				}
			</script>
		
<!-- comScore --><noscript><img src="https://b.scorecardresearch.com/p?c1=2&c2=5641052&cv=2.0&cj=1" /></noscript><!-- comScore end -->
<style>
		body{background-color:#fff;}
		.navbar {margin-bottom:0px;}
		.navbar-nav a.soc {padding:10px;}
		</style>

					 <style>
					 .rdv-alerts {
					   font-family: Open Sans,Helvetica Neue,Helvetica,Arial,sans-serif;
					   color: #fff;
					   min-height: 10px;
					   font-size: 14px;
					     display: block;
					     border: none;
					     background: -webkit-linear-gradient(-45deg,#ec5252,#6e1a1a);
					     background: -moz-linear-gradient(-45deg,#ec5252 0,#6e1a1a 100%);
					     background: -ms-linear-gradient(-45deg,#ec5252 0,#6e1a1a 100%);
					     background: -o-linear-gradient(-45deg,#ec5252 0,#6e1a1a 100%);
					     background: linear-gradient(-45deg,#ec5252,#6e1a1a);
					 }

					 .hr-footer {
					 	border: none;
				    height: 20px;
				    width: 100%;
				    height: 50px;
				    margin-top: 0;
				    border-bottom: 1px solid #ffd8be;
				    box-shadow: 0 20px 20px -20px #b50000;
				    margin: -50px auto 7px;
				}


					 .rdv-alerts .col{
					   padding: 5px;
					 }
					 .rdv-alerts span{
					   font-size: 35px;
					 }
					 img.imagen {opacity: 1;transition: opacity 0.3s;}img.imagen[data-src] {opacity: 0;}


					 ul.bottomnav {
					    list-style-type: none;
					    margin: 0;
					    padding: 0;
					    overflow: hidden;
					}

					ul.bottomnav li {float: left;}

					ul.bottomnav li a {
					    display: block;
					    text-align: center;
					    padding: 0 0;
					    text-decoration: none;
					}

				        .nav-link-extra{
			                    background-color:red;
				            border-radius: 10px 2px;
				        }
.kc_fab_main_btn{
  position:fixed;
  right:10px;
  bottom:10px;
  z-index:999999;
  background-color:#F44336;
  width:60px;
  height:60px;
  border-radius:100%;
  background:#F44336;
  border:none;
  outline:none;
  color:#FFF;
  font-size:20px;
  box-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);
  transition:.3s;  
  -webkit-tap-highlight-color: rgba(0,0,0,0);
}


					@media screen and (max-width: 600px){
					    ul.bottomnav li.right,
					    ul.bottomnav li {float: none;}

							.footer-info{
								text-align:center;
							}
                                            .kc_fab_main_btn{
                                               position:fixed;
					       bottom:120px!important;
					       left:10px;
                                               width:40px;
                                               height:40px;
					       z-index:99999999;
                                         
                                            }
					}

					 </style>

					 <footer id="webFooter">

					 <div>


           <div class="container">


           <div class="row">
            <div class="col-lg"><h5 class="modal-title">Categor&iacute;as</h6><a class="btn btn-link btn-sm left " href="/administracion_empresas" role="button">Administración y Empresas</a><a class="btn btn-link btn-sm left " href="/agricultura" role="button">Agricultura</a><a class="btn btn-link btn-sm left " href="/alimentacion" role="button">Alimentación</a><a class="btn btn-link btn-sm left " href="/arquitectura_construccion" role="button">Arquitectura y Construcción</a><a class="btn btn-link btn-sm left " href="/arte_diseno_musica" role="button">Arte, Diseño y Música</a><a class="btn btn-link btn-sm left " href="/biologia" role="button">Biología</a><a class="btn btn-link btn-sm left " href="/ciencias_politicas" role="button">Ciencias políticas</a><a class="btn btn-link btn-sm left " href="/cocina" role="button">Cocina</a><a class="btn btn-link btn-sm left " href="/derecho" role="button">Derecho</a><a class="btn btn-link btn-sm left " href="/ecologia" role="button">Ecología</a><a class="btn btn-link btn-sm left " href="/economia_comercio" role="button">Economía y comercio</a><a class="btn btn-link btn-sm left " href="/educacion" role="button">Educación</a><a class="btn btn-link btn-sm left " href="/educacion_fisica_deporte" role="button">Educación física y deporte</a><a class="btn btn-link btn-sm left " href="/electronica_mecanica" role="button">Electrónica y Mecánica</a><a class="btn btn-link btn-sm left " href="/estetica" role="button">Estética</a><a class="btn btn-link btn-sm left " href="/filosofia" role="button">Filosofía</a><a class="btn btn-link btn-sm left " href="/fisica_quimica" role="button">Física y Química</a><a class="btn btn-link btn-sm left " href="/geografia" role="button">Geografía</a><a class="btn btn-link btn-sm left " href="/historia" role="button">Historia</a><a class="btn btn-link btn-sm left " href="/idiomas_linguistica" role="button">Idiomas y Lingüística</a><a class="btn btn-link btn-sm left " href="/informatica" role="button">Informática</a><a class="btn btn-link btn-sm left " href="/ingenieria" role="button">Ingeniería</a><a class="btn btn-link btn-sm left " href="/literatura" role="button">Literatura</a><a class="btn btn-link btn-sm left " href="/matematicas" role="button">Matemáticas</a><a class="btn btn-link btn-sm left " href="/medicina_salud" role="button">Medicina y Salud</a><a class="btn btn-link btn-sm left " href="/periodismo" role="button">Periodismo</a><a class="btn btn-link btn-sm left " href="/psicologia" role="button">Psicología</a><a class="btn btn-link btn-sm left " href="/publicidad_relaciones_publicas" role="button">Publicidad y relaciones públicas</a><a class="btn btn-link btn-sm left " href="/sociologia_antropologia" role="button">Sociología y Antropología</a><a class="btn btn-link btn-sm left " href="/turismo" role="button">Turismo</a><a class="btn btn-link btn-sm left " href="/varios" role="button">Varios</a><a class="btn btn-link btn-sm left " href="/veterinaria" role="button">Veterinaria</a>  </div>
                            </li></div>
           </div>
           </div>
 				 </div>
				 <hr/>

				 <div class="container footer-info" >
				 	<a href="https://www.rincondelvago.com" class="navbar-brand"><img style="width: 150px;" src="https://rdv-files.nyc3.cdn.digitaloceanspaces.com/rinvago/static-content/images/logo-rdv.png" alt="Rincón del Vago"></a>
					<div class="row align-top justify-content-center" style="font-size:11px;">
						<div class="col-md-4 col-12 col-lg-3">
							Otros sitios del grupo: <br/>
							<ul class="bottomnav">
								<li><a style="color:red;font-size:11px;"  target="_blank" rel="noopener noreferrer" href="https://www.starmedia.com">StarMedia</a></li>
								<li style="margin-left:10px;font-size:11px;"><a style="color:red; font-size:11px;" target="_blank" rel="noopener noreferrer" href="https://www.autocity.com">AutoCity</a></li>
								<li style="margin-left:10px;font-size:11px;"><a style="color:red; font-size:11px;"  target="_blank" rel="noopener noreferrer" href="https://www.chueca.com">Chueca</a></li>
								<li style="margin-left:10px;font-size:11px;"><a style="color:red; font-size:11px;"  target="_blank" rel="noopener noreferrer" href="https://www.mujeraldia.com">Mujer al día</a></li>
							</ul>

						</div>
						<div class="col-md-4 col-12 col-lg-3">
							&copy; 1998-2018,  Rincón del Vago. <br/>
							Todos los derechos reservados.
						</div>
						<div class="col-md-4 col-12 col-lg-3">
							<a href="https://www.rincondelvago.com/servicios/condiciones.php" style="font-size:11px;">T&eacute;rminos y condiciones</a>
							<br/>
							<a href="https://www.rincondelvago.com/servicios/condiciones.php" style="font-size:11px;">Aviso de privacidad</a>
						</div>
						<div class="col-md-4 col-12 col-lg-3">
							<ul class="nav">
								<li class="nav-item">
								<a style="font-size:11px;" href="http://facebook.com/elrincondelvago" class="nav-link" style="font-size:11px;"><i class="fa fa-facebook-square fa-2x" aria-hidden="true"></i></a>
								</li>
								<li class="nav-item">
								<a style="font-size:11px;" href="http://twitter.com/elrincondelvago" class="nav-link" style="font-size:11px;"><i class="fa fa-twitter-square fa-2x" aria-hidden="true"></i></a>
								</li>
								<li class="nav-item">
								<a style="font-size:11px;" href="https://plus.google.com/108524715945743684741" class="nav-link" style="font-size:11px;"><i class="fa fa-google-plus-square fa-2x" aria-hidden="true"></i></a>
								</li>
							</ul>
						</div>

					</div>



				 </div>
				 <div class="rdv-alerts">

				 </div>

	</footer>
				 <script type="text/javascript">
				  window._taboola = window._taboola || [];
				  _taboola.push({flush: true});
				</script></body>
</html>